# Statistical-Data-Analysis
Statistical Data Analysis
This script describes customer's behaviour by analysing users subscription to the two plans of megaline. It also shows the revenues generated via each plan

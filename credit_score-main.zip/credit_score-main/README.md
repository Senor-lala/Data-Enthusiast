# credit_score

This script contains the data processing and analysis of a report for a bank’s loan division.
It evaluates the ability of a potential borrower to repay their loan.
